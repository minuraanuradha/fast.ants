class Q5 {
    public static void main(String[] args)
    {
     double height = Double.parseDouble(args[0]);
     double weight = Double.parseDouble(args[1]);
     double width = Double.parseDouble(args[2]);

     double Volume = height * weight * width ;
     
   System.out.println("Volume is  "+Volume);
     
     
    }

}