class Q3
{
    public static void main(String[] args)
    {
        System.out.println("You are " + args[0] + " years old"); // Enter your ages
        System.out.println("You are " + args[1] + " years old");
    }
}