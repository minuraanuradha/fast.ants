class Q4
{
    public static void main(String[] args)
    {
        
        double F ;

        int C = Integer.parseInt(args[0]);

        F = (1.8 * C ) + 32 ;

        System.out.println("Temp is : "+F);



    }
}